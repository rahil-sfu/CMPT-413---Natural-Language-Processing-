Concurrently worked on the baseline implementation with Garvit and Rahil.
Wrote the report and some documentation so far.